/*LESS Assignment*/

Please visit ./portfolio/sort-less/sort-less.html for the demo of this LESS.

sort_less.less - LESS file for Sort the Dawgs! page. 
*Note: button.css and sort.css is combined into one file (sort_less.less) for easier coding.

sort_less_production-ready.css - CSS file created from sort_less.less file.

sort_original.css - original CSS file from sort.html 

button_original.css - original CSS file from sort.html 

